cmake_minimum_required(VERSION 3.20)
project(iPhone2PS5 C)

if(NOT DEFINED ENV{PS5SDK})
    message(FATAL_ERROR "Set PS5SDK to the root of the PS5SDK checkout")
endif()

add_executable(iPhone2PS5
    src/payload.c
)

target_include_directories(iPhone2PS5 PRIVATE
    "$ENV{PS5SDK}/include"
)

# This is a source scaffold only. Final link settings must follow
# the exact PS5SDK revision and its example-project conventions.
