/*
 * iPhone2PS5 — initial payload entrypoint scaffold
 *
 * This file intentionally does NOT claim to scan USB devices.
 * USB host access on the target firmware must be proven first.
 */

#include <stdio.h>
#include <ps5/payload_main.h>

void payload_main(struct payload_args *args)
{
    (void)args;

    printf("\n");
    printf("====================================\n");
    printf(" iPhone2PS5 - diagnostic scaffold\n");
    printf("====================================\n");
    printf("Payload entrypoint reached.\n");
    printf("USB Host probing: NOT IMPLEMENTED.\n");
    printf("No iPhone connection or file transfer performed.\n");
    printf("\n");
}
