# مراجع تقنية

- PS5SDK: https://github.com/PS5Dev/PS5SDK
- PS5SDK README: https://github.com/PS5Dev/PS5SDK/blob/main/README.md
- PS5SDK DLSym notes: https://github.com/PS5Dev/PS5SDK/blob/main/docs/dlsym.md

هذه المراجع تصف SDK وآلية بناء payloads. لا تعتبر بحد ذاتها إثباتاً لعمل USB Host أو اتصال iPhone على Firmware 9.60.
